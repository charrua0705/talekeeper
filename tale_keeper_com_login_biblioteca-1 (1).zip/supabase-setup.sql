-- TALE KEEPER: tabela de livros pessoais e políticas de segurança
-- Execute este SQL no Supabase: SQL Editor > New query > Run.

create table if not exists public.books (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  author text not null default '',
  category text not null default '',
  description text not null default '',
  cover_url text not null default '',
  created_at timestamptz not null default now()
);

alter table public.books enable row level security;

drop policy if exists "Users can read their own books" on public.books;
create policy "Users can read their own books"
on public.books for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can add their own books" on public.books;
create policy "Users can add their own books"
on public.books for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can update their own books" on public.books;
create policy "Users can update their own books"
on public.books for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own books" on public.books;
create policy "Users can delete their own books"
on public.books for delete
to authenticated
using (auth.uid() = user_id);

create index if not exists books_user_id_created_at_idx
on public.books (user_id, created_at desc);
